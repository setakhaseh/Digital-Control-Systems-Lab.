def delay(ms):
    initTime = robot.getTime()      # Store starting time (in seconds)
    while robot.step(timestep) != -1:
        if (robot.getTime() - initTime) * 1000.0 > ms: # If time elapsed (converted into ms) is greater than value passed in
            break

    
# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot

# create the Robot instance.
robot = Robot()
def run_robot():
    pass
    

# get the time step of the current world.
timestep = int(robot.getBasicTimeStep())
MAX_SPEED = 6.28

# You should insert a getDevice-like function in order to get the
# instance of a device of the robot. Something like:
#  motor = robot.getDevice('motorname')
#  ds = robot.getDevice('dsname')
#  ds.enable(timestep)
leftMotor = robot.getDevice('left wheel motor')
rightMotor = robot.getDevice('right wheel motor')

#leftMotor.setPosition(10.0)
#rightMotor.setPosition(10.0)

leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))

#initializing the variables

prox_sensors=[]
i=0
j=0
compass=0
nodes_data={(i,j,compass):['b','l','r','f']}
for sens in range(8):
    sensor_name='ps'+str(sens)
    prox_sensors.append(robot.getDevice(sensor_name))
    prox_sensors[sens].enable(timestep)
front_wall=False
right_wall=False
back_wall=False
left_wall=False
turned_back=False
#sensor reading
def read_sensors():
    global front_wall,right_wall,back_wall,left_wall
    front_wall=prox_sensors[0].getValue()>80 or prox_sensors[7].getValue()>80
    right_wall=prox_sensors[2].getValue()>80
    back_wall=prox_sensors[3].getValue()>80 or prox_sensors[4].getValue()>80
    left_wall=prox_sensors[5].getValue()>80
#movements
    
def turnRight():
    global i,j,nodes_data,compass
    compass_detector()
    if compass != 3:
        compass+=1
    else:
        compass=0
    if (i, j,compass) not in nodes_data:
        nodes_data[(i,j,compass)] = ['b', 'l', 'r', 'f']
    if nodes_data[(i,j,compass)]:
        print("right")
        leftMotor.setVelocity(.5 * MAX_SPEED)
        rightMotor.setVelocity(-.5 * MAX_SPEED)
        delay(750)
        moveahead()
    else:
        Turnback()
    
    

def Turnback():
    global i,j,nodes_data,compass,turned_back
    if compass<2:
            compass+=2
    else:
            compass-=2    
    compass_detector()
    if (i, j,compass) not in nodes_data:  
        print("new node is made")
        nodes_data[(i,j,compass)] = ['b', 'l', 'r', 'f']
    if nodes_data[(i,j,compass)]:
        print("back")
        leftMotor.setVelocity(-.5 * MAX_SPEED)
        rightMotor.setVelocity(-.5 * MAX_SPEED)
        delay(750)
        moveahead()
    else:
        turned_back=True
        if compass<2:
            compass+=2
        else:
            compass-=2    
        compass_detector()
        if (i, j,compass) not in nodes_data:  
            nodes_data[(i,j,compass)] = ['b', 'l', 'r', 'f']
        else:
            print("back")
            leftMotor.setVelocity(-.5 * MAX_SPEED)
            rightMotor.setVelocity(-.5 * MAX_SPEED)
            delay(750)
            moveahead()


def TurnLeft():
    global i,j,nodes_data,compass
    compass_detector()
    if compass !=0:
        compass-=1
    else:
        compass=3
    if (i, j,compass) not in nodes_data:
        nodes_data[(i,j,compass)] = ['l', 'r', 'f']
    if nodes_data[(i,j,compass)]:
        print("left")
        leftMotor.setVelocity(-.5 * MAX_SPEED)
        rightMotor.setVelocity(.5 * MAX_SPEED)
        delay(750) 
        moveahead()
    else:
        Turnback()

    

def moveforward():
    global i,j,nodes_data,compass,turned_back
    turned_back=False
    compass_detector()
    if (i, j,compass) not in nodes_data: 
        nodes_data[(i,j,compass)] = ['l','r', 'f']
    if nodes_data[(i,j,compass)]:
        print("moveforward")
        leftMotor.setVelocity(MAX_SPEED)
        rightMotor.setVelocity(MAX_SPEED)
        delay(3000)
    else:
        Turnback()

def moveahead():
    print("moveahead")
    leftMotor.setVelocity(MAX_SPEED)
    rightMotor.setVelocity(MAX_SPEED)
    delay(750)


    

# ...

def direction_deleter():
    global nodes_data, i, j, compass,front_wall,right_wall,back_wall,left_wall
    if front_wall:
        if 'f' in nodes_data[(i, j, compass)]:
            nodes_data[(i, j, compass)].remove('f')
    if right_wall:
        if 'r' in nodes_data[(i, j, compass)]:
            nodes_data[(i, j, compass)].remove('r')
    if back_wall:
         if 'b' in nodes_data[(i, j, compass)]:
             nodes_data[(i, j, compass)].remove('b')
    if left_wall:
         if 'l' in nodes_data[(i, j, compass)]:
             nodes_data[(i, j, compass)].remove('l')

def direction_chooser(x):
    global compass, i, j
    print("direction is chosed")
    match x:
        case 'f':
            moveforward()
        case 'r':
            turnRight()
        case 'l':
            TurnLeft()
        #case 'b':
            #Turnback()

def compass_detector():
    global i, j, compass
    if compass == 0:
        j += 1
    elif compass == 1:
        i += 1
    elif compass == 2:
        j -= 1
    else:
        i -= 1

# Main loop:
while robot.step(timestep) != -1:
    # Read the sensors:
    for sens in range(8):
        print("sense:{}, val:{}".format(sens, prox_sensors[sens].getValue()))
    # Enter here functions to read sensor data, like:
    read_sensors()
    # delete the directions blocked by a wall
    direction_deleter()
    
    # direction_chooser
    print(i)
    print(j)
    print(compass)
    if nodes_data[(i,j,compass)]:
        print("locked here")
        direction_chooser(nodes_data[(i, j, compass)].pop())
    elif not turned_back:
        Turnback()
    else:
        moveforward()


leftMotor.setVelocity(0)
rightMotor.setVelocity(0)
